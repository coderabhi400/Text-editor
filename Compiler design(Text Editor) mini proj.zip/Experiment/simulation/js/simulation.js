const editor = document.getElementById('text-editor');
const sword = document.getElementById('sword-editor');
/*function f1() {
	//function to make the text bold using DOM method
	editor.style.fontWeight = "bold";
}

function f2() {
	//function to make the text italic using DOM method
	editor.style.fontStyle = "italic";
}

function f3() {
	//function to make the text alignment left using DOM method
	editor.style.textAlign = "left";
}

function f4() {
	//function to make the text alignment center using DOM method
	editor.style.textAlign = "center";
}

function f5() {
	//function to make the text alignment right using DOM method
	editor.style.textAlign = "right";
}
*/
function f6() {
	//function to make the text in Uppercase using DOM method
	editor.style.textTransform = "uppercase";
}

function f7() {
	//function to make the text in Lowercase using DOM method
	editor.style.textTransform = "lowercase";
}

function f8() {
	//function to make the text capitalize using DOM method
	editor.style.textTransform = "capitalize";
}

function f9() {
	//function to make the text back to normal by removing all the methods applied
	//using DOM method
	editor.innerHTML = "";
	updateCounts();
}

function f10() {
	editor.style.fontWeight = "normal";
	editor.style.textAlign = "left";
	editor.style.fontStyle = "normal";
	editor.style.textTransform = "none";
}
///function f11(){
//	const text = editor.innerText;
//	var count = (text.match(/is/g) || []).length;
//	console.log = function(message) {
	//	document.getElementById('result').innerHTML = message;
	//};
  //  console.log(count);
//}
/*
function copyToClipboard(element) {
	var $temp = $("<textarea>");
	var brRegex = /<br\s*[\/]?>/gi;
	$("body").append($temp);
	$temp.val($(element).html().replace(brRegex, "\r\n")).select();
	document.execCommand("copy");
	$temp.remove();
  }
  
  $( "#FailCopy" ).click(function() {
	alert("Text copied to clipboard");
  });
  
function f12() {
	navigator.clipboard.writeText("Now is the time to make real the promises of democracy. Now is the time to rise from the dark and desolate valley of segregation to the sunlit path of racial justice. Now is the time to lift our nation from the quicksands of racial injustice to the solid rock of brotherhood. Now is the time to make justice a reality for all of God's children.").then(() => {
		//console.log('Content copied to clipboard');
		alert("Text copied!")
		/* Resolved - text copied to clipboard successfully */
	//  },() => {
	//	console.error('Failed to copy');
		/* Rejected - text failed to copy to the clipboard */
//	  });
 // }

function updateCounts() {
	let chars, words, lines;
	const text = editor.innerText;
	var newstr = "";
for( var i = 0; i < text.length; i++ ) 
    if( !(text[i] == '\n' || text[i] == '\r') )
        newstr += text[i];
	chars = newstr.length;
	// [A-Za-z]\w* for words starting with aplphabet and may have number
	words = Array.from(text.matchAll(/\w+/g)).length;
	lines = text.length > 0 ? Array.from(text.matchAll(/\n/g)).length + 1: 0;
	let doubleLines = Array.from(text.matchAll(/\n\n/g)).length;
	const parent = document.querySelector('#count-output');
	parent.querySelector('.chars').innerHTML = '' + chars;
	parent.querySelector('.words').innerHTML = '' + words;
	parent.querySelector('.lines').innerHTML = '' + (lines - doubleLines);
}



function swords() {
	let snum = sword.innerText;
	const text = editor.innerText;
	let nlines = text.split("\n");
 	var regex = new RegExp(snum,"g");
	var count = 0;
	for(let i=0; i<nlines.length; i++){
		let s = nlines[i]
		count += snum.length > 0 ? (s.match(regex) || []).length : 0
	}

    console.log(count);
    //    let text = document.getElementById("text").innerHTML;
     //   let re = new RegExp(searched,"g"); // search for all instances
	 if (snum != ''){
        let newText = [];
		for(let i=0; i<nlines.length; i++){
			newText[i] = nlines[i].replace(regex, `<mark>${snum}</mark>`)
		}
		console.log(newText)
    	document.getElementById("text-editor").innerHTML = newText.join("<br>");
		document.querySelector("#result").innerText = count
	 }
	 else{
		document.querySelector("#result").innerText = 0;
	 }
	 if (snum == ''){
		document.getElementById("text-editor").innerHTML = nlines.join("<br>");
	}
}
editor.addEventListener('keyup', updateCounts);
updateCounts();
sword.addEventListener('keyup', swords);
