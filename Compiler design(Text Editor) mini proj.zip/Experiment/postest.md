Q 1. Scanner is also known as:
<b>a. Lexical Analyser</b>  
b. Syntax Analyser
c. Semantic Analyser  
d. None of the above    

Q 2. What do we put after a character to match strings where that character appears two to four times in sequence? 
<b>a. {2,4}</b>  
b. {2,-4}  
c. [2,4]    
d. None of the above 

Q 3. The regular expression \d{4} will match what? 
a. Any four character sequence  
<b>b. Any four digit sequence</b>   
c. The letter d four times  
d. None of the above  

Q 4. The output product of scanner is:  
<b>a. Tokens</b>   
b. Lexemes  
c. Both
d. None of the above  

Q 5.  A single period (.) in a regular expression, outside of groups of other exceptions, represents what?  
a. The end of a sentence
<b>b. Any single character</b>  
c. A space
d. Any punctuation mark
 
