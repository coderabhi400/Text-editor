This experiment is developed by Dr. Biswajit R. Bhowmik and his UG students- K V Harish Babu, Shashank J Bennehalli, Mohammed Mansoor And Abhishek Kumar Singh, Department of Computer Science and Engineering, National Institute of Technology, Karnataka.
        
          A.  Textbook References
              1. Alfred V. Aho, Monica S. Lam, Ravi Seathi, Jeffery D. Ullman. Compilers: Principles Techniques and Tool. Pearson Education India; 2nd edition (1 January 2013).
          B.  Web References
              1. https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions
              2. https://www.vlab.co.in/broad-area-computer-science-and-engineering