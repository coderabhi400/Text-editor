### Scanning
  Scanning is the process of identifying tokens from the raw text source code of a program. Identifying tokens in source code requires  the language designer to clarify many fine details, so that it is clear what is permitted and what is not.
  Most languages will have tokens in these categories:
  1. Keywords such as int, char, float, const, goto, continue, etc. 
  1. Identifiers (user-defined names)
  1. Operators such as +, -, *, / 
  1. Punctuators like comma (,), semicolon(;), braces ({ }), etc.
  1. Strings

### Regular Expressions
  A Regex or Regular Expression is a string of text that lets you create patterns that help match, locate, and manage text. 
  Precise Definition of Regular Expression: A regular expression s is a string which denotes L(s), a set of strings drawn from an alphabet Σ. L(s) is known as the “language of s.”Using regular expressions, we can precisely state what is permitted in a given token. 
  The following figure shows the example of a regular expression for Email Matching. 
![Regex!](/images/reg.png "Regular expression")
#### Advantages and Disadvantages of Regular Expressions
| Advantages                                                                                                                | Disadvantages                                                                                 |
|---------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| Regular Expressions can be used in this case to recognize the patterns and extract the required information easily.       | Regular Expressions are less powerful and restricted compared to Context Free Grammars.       |
| Supported by almost any language, there are only a few programming languages which do not understand regular expressions. | The range of languages that come under Regular Expression is less than Context Free Grammars. |
| Allows you to do some very intricate character replacement.                                                               | It cannot specify the recursive structures of the programming language.                       |
| Clear and concise code yet very fast and efficient.                                                                       | Cannot define irregular language.                                                             |
#### Operations
The various operations on languages are:
  Union of two languages L and M is written as
  L U M = {s | s is in L or s is in M}
  Concatenation of two languages L and M is written as
  LM = {st | s is in L and t is in M}
  The Kleene Closure of a language L is written as
  L* = Zero or more occurrence of language L.
#### Notations
If q and s are regular expressions denoting the languages L(q) and L(s), then
  Union : (q) |(s) is a regular expression denoting L(q) U L(s)
  Concatenation : (q) (s) is a regular expression denoting L(q)L(s)
  Kleene closure : (q)* is a regular expression denoting (L(r))*
#### Precedence and Associativity
  (star sign) , concatenation (.), and | (pipe sign) are left associative
  "*" has the highest precedence
  Concatenation (.) has the second highest precedence.
  | (pipe sign) has the lowest precedence of all.
### \0
  '\0' is referred to as NULL character or NULL terminator It is the character equivalent of integer 0(zero) as it refers to nothing In C language it is generally used to mark an end of a string.