Q 1. Any regular expression r can be transformed into an 'equivalent' NFA. True or False?  
<b>a) True</b>  
b) False

Q 2. Regular expressions can be used to search-  
a) Images
<b> b) Text </b>  
c) Videos  
d) None of the above  

Q 3. What is something a regular expression CANNOT be used for?
a) Searching for repetitive characters
<b>b) Replacing text</b>
c) Validating equation answers
d) Validating date formatting 

Q 4. What regular expression matches the strings dog or cat?  
<b>a) dog|cat</b>
b) dog,cat  
c) dog | cat 
d) None of the above

Q 5. Which of the following matches any space, tab, or newline?    
<b>a) \\s</b>  
b) \\b
c) $
d) None of the above  
