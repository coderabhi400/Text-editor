##### Steps of simulator : 

  1. Enter a sample text of your choice on the editor.
  2. The count of characters, words and lines will be displayed dynamically.
  3. Enter specific word to find the number of times it appears in the text.          
  4. To change the text into upper case/ lower case press the "Upper Case"/ "Lower Case" button.
  5. To capitalize all the words in the editor press "Capitalize" button.
  6. To clear the formatting performed on the text press "Clear Formatting" button.
  7. To enter a new text, press "Clear Text" text at the top of the editor.