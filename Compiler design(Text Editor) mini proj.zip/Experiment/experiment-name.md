## Designing a text editor
