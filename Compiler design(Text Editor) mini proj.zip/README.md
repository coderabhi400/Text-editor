## Introduction


Discipline | Computer Science and Engineering
:--|:--|
 Lab |  Compiler Design
 Experiment|      Designing a text editor.

### About the Experiment 

Design a text editor to count the number of characters, words and lines.

Name of Developer |  Dr. Biswajith R Bhowmik
:--|:--|
 Institute |   National Institute of Technology Karnataka, Surathkal
 Email id|       brb@nitk.edu.in
 Department |   Computer Science and Engineering

### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | K V Harish Babu | Student | Computer Science and Engineering | National Institute of Technology Karnataka, Surathkal | kvharishbabu.201cs233@nitk.edu.in
2 | Shashank J Bennehalli | Student | Computer Science and Engineering | National Institute of Technology Karnataka, Surathkal | jbs.191cs248@nitk.edu.in
3 | Mohammed Mansoor | Student | Computer Science and Engineering | National Institute of Technology Karnataka, Surathkal | mohammedmansoor.201cs223@nitk.edu.in
4 | Abhishek Kumar Singh | Student | Computer Science and Engineering | National Institute of Technology Karnataka, Surathkal | abhishekkumarsingh.201cs202@nitk.edu.in
